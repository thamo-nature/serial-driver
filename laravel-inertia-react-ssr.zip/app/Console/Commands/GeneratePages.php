<?php

namespace App\Console\Commands;

use App\Models\Location;
use App\Models\PageInstance;
use App\Models\PageTemplate;
use App\Models\Product;
use Illuminate\Console\Command;

/**
 * Fans out the programmatic SEO matrix into page_instances:
 *
 *   PAGE = PageTemplate x Product(optional) x Location
 *
 * Idempotent (updateOrCreate on the unique matrix key): re-running NEVER
 * clobbers a human's is_published choice — it only fills url_path / defaults
 * for NEW combinations. Sparse by design: only locations whose type is in
 * template.applies_to (and, if requires_branch, that actually have a branch)
 * get a row.
 *
 * Usage:
 *   php artisan pages:generate
 *   php artisan pages:generate --template=best-mobile-phones-nearme
 *   php artisan pages:generate --product=best-mobile-phones
 */
class GeneratePages extends Command
{
    protected $signature = 'pages:generate
        {--template= : limit to one page_template key}
        {--product= : limit to one product slug}';

    protected $description = 'Generate page_instances from the Template x Product x Location matrix';

    public function handle(): int
    {
        $templates = PageTemplate::query()->where('is_active', true)
            ->when($this->option('template'), fn ($q, $k) => $q->where('key', $k))
            ->get();

        if ($templates->isEmpty()) {
            $this->warn('No active templates found.');

            return self::SUCCESS;
        }

        $created = 0;
        $skipped = 0;

        foreach ($templates as $template) {
            // locations whose TYPE is allowed by this template (sparsity gate 1)
            $locations = Location::query()
                ->where('is_active', true)
                ->whereHas('type', fn ($q) => $q->whereIn('key', $template->applies_to))
                ->with(['branches', 'type'])
                ->get();

            // product set
            $products = $template->requires_product
                ? Product::query()->where('is_active', true)
                    ->when($this->option('product'), fn ($q, $s) => $q->where('slug', $s))
                    ->get()
                : collect([null]);

            foreach ($locations as $location) {
                // sparsity gate 2: eligibility (branch requirement)
                if ($template->requires_branch && $location->branches->isEmpty()) {
                    $skipped++;

                    continue;
                }

                foreach ($products as $product) {
                    $urlPath = $template->buildUrlPath($product, $location);

                    [$instance, $wasRecentlyCreated] = $this->upsertInstance(
                        $template, $product, $location, $urlPath
                    );

                    $wasRecentlyCreated ? $created++ : $skipped++;
                }
            }
        }

        $this->info("pages:generate complete. Created: {$created}, existing/skipped: {$skipped}.");

        return self::SUCCESS;
    }

    /**
     * @return array{0:PageInstance,1:bool}
     */
    private function upsertInstance(PageTemplate $template, ?Product $product, Location $location, string $urlPath): array
    {
        $existing = PageInstance::query()
            ->where('page_template_id', $template->id)
            ->where('product_id', $product?->id)
            ->where('location_id', $location->id)
            ->first();

        if ($existing) {
            // keep is_published (human choice); refresh url_path if the slug changed.
            if ($existing->url_path !== $urlPath) {
                $existing->update(['url_path' => $urlPath]);
                // NOTE: a Redirect from old->new path would be created here in prod.
            }

            return [$existing, false];
        }

        $sitemapGroup = $this->sitemapGroupFor($location);

        $instance = PageInstance::create([
            'page_template_id' => $template->id,
            'product_id' => $product?->id,
            'location_id' => $location->id,
            'url_path' => $urlPath,
            'is_published' => $template->default_published,
            'indexable' => true,
            'priority' => $template->default_priority,
            'changefreq' => $template->default_changefreq,
            'sitemap_group' => $sitemapGroup,
            'meta_title' => $template->renderPattern($template->title_pattern, $product, $location),
            'meta_description' => $template->renderPattern($template->description_pattern, $product, $location),
        ]);

        return [$instance, true];
    }

    /**
     * Chunk key for the sitemap index: group by the state (depth 2) slug when
     * available, else by the location's own top segment. Keeps child sitemaps
     * well under the 45k URL cap.
     */
    private function sitemapGroupFor(Location $location): string
    {
        $segments = explode('/', (string) $location->full_path);

        // segments[0]=country, segments[1]=state (if present)
        return $segments[1] ?? ($segments[0] ?? 'root');
    }
}
