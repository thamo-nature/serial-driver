<?php

namespace App\Jobs;

use App\Services\Seo\CachePurger;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;

/**
 * Queued cache/sitemap/CDN invalidation. Dispatched by the PageInstance
 * observer (and by bulk publish actions) so a request never blocks on purging.
 *
 * Carries only the affected absolute URLs (small, serialisable) — not Models.
 * Debounce-friendly: a bulk action dispatches ONE job with many URLs.
 */
class PurgePageCache implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    /**
     * @param  array<int,string>  $urls  absolute URLs to purge at the CDN
     */
    public function __construct(public array $urls = []) {}

    public function handle(CachePurger $purger): void
    {
        $purger->purge($this->urls);
    }

    /** Collapse duplicate purge jobs within a short window (if using unique). */
    public function uniqueId(): string
    {
        return md5(implode('|', $this->urls));
    }
}
