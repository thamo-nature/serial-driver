<?php

namespace App\Services\Seo;

use App\Models\PageInstance;

/**
 * Produces the complete SEO payload for a page from the PageInstance (SSOT)
 * plus config — all absolute URLs derived from config('app.url'), robots from
 * config('seo.indexable') + is_published + indexable. Nothing hardcoded, so
 * the UAT -> Live switch is a single .env change.
 *
 * Output is passed as the `seo` Inertia prop and rendered inside React <Head>
 * (SSR), so every tag appears in View Source for crawlers.
 */
class SeoBuilder
{
    public function __construct(private BreadcrumbBuilder $breadcrumbs) {}

    public function forInstance(PageInstance $instance): array
    {
        $instance->loadMissing(['product', 'location.branches', 'template']);

        $canonical = $instance->canonical();
        $title = $instance->meta_title ?: $this->fallbackTitle($instance);
        $description = $instance->meta_description ?: $this->fallbackDescription($instance);

        $breadcrumb = $this->breadcrumbs->forInstance($instance);

        return [
            'title' => $title,
            'description' => $description,
            'canonical' => $canonical,
            'robots' => $instance->robots(),
            'og' => [
                'title' => $title,
                'description' => $description,
                'url' => $canonical,
                'type' => 'website',
            ],
            'lead_form_url' => config('seo.lead_form_url'),
            'breadcrumb' => $breadcrumb['items'],
            // JSON-LD @graph: breadcrumb + product + each branch's LocalBusiness
            'schema' => $this->schemaGraph($instance, $breadcrumb['schema']),
        ];
    }

    private function fallbackTitle(PageInstance $instance): string
    {
        $product = $instance->product?->name;
        $location = $instance->location->name;

        return $product
            ? "{$product} Near Me in {$location}"
            : "Near Me in {$location}";
    }

    private function fallbackDescription(PageInstance $instance): string
    {
        $product = $instance->product?->name ?? 'services';
        $location = $instance->location->name;

        return "Discover the best {$product} near you in {$location}. Compare prices, offers and nearby branches.";
    }

    /**
     * Build the JSON-LD @graph as a native array.
     */
    private function schemaGraph(PageInstance $instance, array $breadcrumbSchema): array
    {
        $graph = [$breadcrumbSchema];

        // Product node (if product-scoped)
        if ($instance->product) {
            $graph[] = [
                '@type' => 'Product',
                'name' => $instance->product->name,
                'description' => $instance->product->description,
                'url' => $instance->canonical(),
            ];
        }

        // LocalBusiness node per active branch on this location
        foreach ($instance->location->branches as $branch) {
            if (! $branch->is_active) {
                continue;
            }

            $node = [
                '@type' => 'LocalBusiness',
                'name' => $branch->name,
                'url' => $instance->canonical(),
                'telephone' => $branch->phone,
                'address' => array_filter([
                    '@type' => 'PostalAddress',
                    'streetAddress' => $branch->address_line1,
                    'addressLocality' => $branch->city,
                    'addressRegion' => $branch->state,
                    'postalCode' => $branch->postal_code,
                    'addressCountry' => $branch->country,
                ]),
            ];

            if ($branch->lat && $branch->lng) {
                $node['geo'] = [
                    '@type' => 'GeoCoordinates',
                    'latitude' => (float) $branch->lat,
                    'longitude' => (float) $branch->lng,
                ];
            }

            $graph[] = $node;
        }

        return [
            '@context' => 'https://schema.org',
            '@graph' => $graph,
        ];
    }
}
