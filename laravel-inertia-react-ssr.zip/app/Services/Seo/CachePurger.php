<?php

namespace App\Services\Seo;

use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

/**
 * Central cache/sitemap/CDN invalidation.
 *
 * Caching strategy is store-aware:
 *   - Taggable stores (Redis): page/sitemap entries are tagged; purge flushes
 *     the tag -> precise, cheap.
 *   - Non-taggable stores (database/file, the current default): we keep a
 *     monotonically increasing VERSION integer in the cache and bake it into
 *     every cache key. Bumping the version instantly invalidates everything
 *     (old keys are simply never read again and expire on TTL).
 *
 * CDN purge is a pluggable hook (log driver by default; Cloudflare supported).
 */
class CachePurger
{
    private const VERSION_KEY = 'seo:cache:version';

    private const SITEMAP_VERSION_KEY = 'seo:sitemap:version';

    /** Current cache version (part of every page/sitemap cache key). */
    public function version(): int
    {
        return (int) Cache::get(self::VERSION_KEY, 1);
    }

    public function sitemapVersion(): int
    {
        return (int) Cache::get(self::SITEMAP_VERSION_KEY, 1);
    }

    /** Build the versioned cache key for a page url_path. */
    public function pageKey(string $urlPath): string
    {
        return 'seo:page:'.$this->version().':'.$urlPath;
    }

    /** Build the versioned cache key for a sitemap fragment. */
    public function sitemapKey(string $fragment): string
    {
        return 'seo:sitemap:'.$this->sitemapVersion().':'.$fragment;
    }

    public function taggable(): bool
    {
        try {
            Cache::tags([config('seo.cache.tag')]);

            return true;
        } catch (\Throwable) {
            return false;
        }
    }

    /**
     * Purge everything related to a changed page/scope:
     *   - flush tag (Redis) or bump the version (db/file),
     *   - bump the sitemap version,
     *   - issue a CDN purge for the affected URL(s).
     *
     * @param  array<int,string>  $urls  absolute URLs to purge at the CDN
     */
    public function purge(array $urls = []): void
    {
        if ($this->taggable()) {
            Cache::tags([config('seo.cache.tag')])->flush();
        } else {
            Cache::increment(self::VERSION_KEY) ?: Cache::put(self::VERSION_KEY, $this->version() + 1);
        }

        $this->bustSitemap();

        if (! empty($urls)) {
            $this->purgeCdn($urls);
        }
    }

    /** Invalidate cached sitemaps only. */
    public function bustSitemap(): void
    {
        Cache::increment(self::SITEMAP_VERSION_KEY) ?: Cache::put(self::SITEMAP_VERSION_KEY, $this->sitemapVersion() + 1);
    }

    /**
     * CDN purge hook. 'log' records intent; 'cloudflare' calls the API.
     *
     * @param  array<int,string>  $urls
     */
    public function purgeCdn(array $urls): void
    {
        $driver = config('seo.cdn.driver', 'log');

        if ($driver === 'cloudflare') {
            $this->purgeCloudflare($urls);

            return;
        }

        Log::info('[CDN purge:log] would purge URLs', ['count' => count($urls), 'urls' => array_slice($urls, 0, 20)]);
    }

    /**
     * @param  array<int,string>  $urls
     */
    private function purgeCloudflare(array $urls): void
    {
        $zone = config('seo.cdn.cloudflare.zone_id');
        $token = config('seo.cdn.cloudflare.api_token');

        if (! $zone || ! $token) {
            Log::warning('[CDN purge:cloudflare] missing zone_id/api_token; skipping');

            return;
        }

        // Cloudflare caps 30 URLs per purge call -> chunk.
        foreach (array_chunk($urls, 30) as $chunk) {
            Http::withToken($token)
                ->post("https://api.cloudflare.com/client/v4/zones/{$zone}/purge_cache", [
                    'files' => array_values($chunk),
                ]);
        }
    }
}
