<?php

namespace App\Services\Seo;

use App\Models\PageInstance;

/**
 * Builds the breadcrumb trail for a page from the location ancestor chain plus
 * the product/template context. Produces BOTH:
 *   - a visual trail (array of {name,url}) for the React <nav>, and
 *   - a schema.org BreadcrumbList array for JSON-LD,
 * from the SAME source so they can never drift.
 *
 * Example trail for /best-mobile-phones-nearme-in-chennai:
 *   Home -> Best Mobile Phones -> Best Mobile Phones Near Me in Chennai
 */
class BreadcrumbBuilder
{
    public function forInstance(PageInstance $instance): array
    {
        $base = rtrim(config('app.url'), '/');
        $items = [];

        // 1. Home
        $items[] = ['name' => 'Home', 'url' => $base.'/'];

        // 2. Product hub (if this page is product-scoped)
        if ($instance->product) {
            $items[] = [
                'name' => $instance->product->name,
                'url' => $base.'/'.$instance->product->slug,
            ];
        }

        // 3. The current page (leaf). Use the rendered title when available.
        $leafName = $instance->meta_title
            ?: trim(($instance->product->name ?? 'Page').' in '.$instance->location->name);

        $items[] = [
            'name' => $leafName,
            'url' => $instance->canonical(),
        ];

        return [
            'items' => $items,
            'schema' => $this->toSchema($items),
        ];
    }

    /**
     * schema.org BreadcrumbList as a native array (JSON-LD ready).
     */
    private function toSchema(array $items): array
    {
        $elements = [];
        foreach ($items as $i => $item) {
            $elements[] = [
                '@type' => 'ListItem',
                'position' => $i + 1,
                'name' => $item['name'],
                'item' => $item['url'],
            ];
        }

        return [
            '@context' => 'https://schema.org',
            '@type' => 'BreadcrumbList',
            'itemListElement' => $elements,
        ];
    }
}
