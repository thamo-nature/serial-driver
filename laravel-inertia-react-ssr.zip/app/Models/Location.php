<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Support\Collection;

class Location extends Model
{
    protected $fillable = [
        'parent_id', 'location_type_id', 'depth',
        'name', 'slug', 'full_path',
        'lat', 'lng', 'sort_order', 'is_active',
        'meta_title', 'meta_description',
    ];

    protected $casts = [
        'depth' => 'integer',
        'lat' => 'decimal:7',
        'lng' => 'decimal:7',
        'sort_order' => 'integer',
        'is_active' => 'boolean',
    ];

    /* ---------------- relationships ---------------- */

    public function parent(): BelongsTo
    {
        return $this->belongsTo(Location::class, 'parent_id');
    }

    public function children(): HasMany
    {
        return $this->hasMany(Location::class, 'parent_id');
    }

    public function type(): BelongsTo
    {
        return $this->belongsTo(LocationType::class, 'location_type_id');
    }

    public function branches(): HasMany
    {
        return $this->hasMany(Branch::class);
    }

    public function pageInstances(): HasMany
    {
        return $this->hasMany(PageInstance::class);
    }

    /* ---------------- scopes ---------------- */

    public function scopeActive(Builder $q): Builder
    {
        return $q->where('is_active', true);
    }

    /* ---------------- tree helpers ---------------- */

    /**
     * Build the denormalised full_path from the ancestor chain.
     * e.g. india / tamil-nadu / chennai
     */
    public function buildFullPath(): string
    {
        $segments = [];
        $node = $this;
        while ($node) {
            array_unshift($segments, $node->slug);
            $node = $node->parent; // relies on parent being loadable
        }

        return implode('/', $segments);
    }

    /**
     * Ancestors from root -> this node's parent (for breadcrumbs).
     *
     * @return Collection<int,Location>
     */
    public function ancestors()
    {
        $chain = collect();
        $node = $this->parent;
        while ($node) {
            $chain->prepend($node);
            $node = $node->parent;
        }

        return $chain;
    }
}
