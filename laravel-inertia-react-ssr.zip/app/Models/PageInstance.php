<?php

namespace App\Models;

use App\Observers\PageInstanceObserver;
use Illuminate\Database\Eloquent\Attributes\ObservedBy;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

#[ObservedBy([PageInstanceObserver::class])]
class PageInstance extends Model
{
    protected $fillable = [
        'page_template_id', 'product_id', 'location_id',
        'url_path', 'is_published', 'indexable',
        'priority', 'changefreq', 'sitemap_group',
        'meta_title', 'meta_description', 'canonical_override',
        'published_at',
    ];

    protected $casts = [
        'is_published' => 'boolean',
        'indexable' => 'boolean',
        'priority' => 'decimal:1',
        'published_at' => 'datetime',
    ];

    /* ---------------- relationships ---------------- */

    public function template(): BelongsTo
    {
        return $this->belongsTo(PageTemplate::class, 'page_template_id');
    }

    public function product(): BelongsTo
    {
        return $this->belongsTo(Product::class);
    }

    public function location(): BelongsTo
    {
        return $this->belongsTo(Location::class);
    }

    /* ---------------- scopes ---------------- */

    public function scopePublished(Builder $q): Builder
    {
        return $q->where('is_published', true);
    }

    /** Pages eligible to appear in the sitemap (published + indexable). */
    public function scopeForSitemap(Builder $q): Builder
    {
        return $q->where('is_published', true)->where('indexable', true);
    }

    /* ---------------- SEO helpers ---------------- */

    /** Absolute canonical URL, always derived from APP_URL unless overridden. */
    public function canonical(): string
    {
        if ($this->canonical_override) {
            return $this->canonical_override;
        }

        return rtrim(config('app.url'), '/').$this->url_path;
    }

    /**
     * robots meta value: index only when the environment is indexable AND the
     * page is published AND the page's own indexable flag is true.
     */
    public function robots(): string
    {
        $indexable = (bool) config('seo.indexable', false)
            && $this->is_published
            && $this->indexable;

        return $indexable ? 'index,follow' : 'noindex,nofollow';
    }
}
