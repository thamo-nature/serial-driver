<?php

namespace App\Models;

// use Illuminate\Contracts\Auth\MustVerifyEmail;
use Database\Factories\UserFactory;
use Illuminate\Database\Eloquent\Attributes\Fillable;
use Illuminate\Database\Eloquent\Attributes\Hidden;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;
use Spatie\Permission\Traits\HasRoles;

#[Fillable(['name', 'email', 'password'])]
#[Hidden(['password', 'remember_token'])]
class User extends Authenticatable
{
    /** @use HasFactory<UserFactory> */
    use HasApiTokens, HasFactory, HasRoles, Notifiable;

    protected function casts(): array
    {
        return [
            'email_verified_at' => 'datetime',
            'password' => 'hashed',
        ];
    }

    /* ---------------- scope relationships ---------------- */

    public function roleScopes(): HasMany
    {
        return $this->hasMany(RoleScope::class);
    }

    public function bookings(): HasMany
    {
        return $this->hasMany(Booking::class);
    }

    /* ---------------- scope helpers ---------------- */

    /**
     * Branch IDs this user is directly scoped to (managers).
     *
     * @return array<int,int>
     */
    public function scopedBranchIds(): array
    {
        return $this->roleScopes()
            ->where('scope_type', 'branch')
            ->pluck('branch_id')
            ->filter()
            ->all();
    }

    /**
     * Location IDs this user is scoped to (editors). Does NOT expand the
     * subtree here; policies/queries can expand via full_path when needed.
     *
     * @return array<int,int>
     */
    public function scopedLocationIds(): array
    {
        return $this->roleScopes()
            ->where('scope_type', 'location')
            ->pluck('location_id')
            ->filter()
            ->all();
    }

    /**
     * True if the user may act on a given branch:
     *  - global roles (super_admin/admin) are handled by Gate::before/policy,
     *  - otherwise the branch must be in their branch scope, OR the branch's
     *    location (or an ancestor) must be in their location scope.
     */
    public function canManageBranch(Branch $branch): bool
    {
        if (in_array($branch->id, $this->scopedBranchIds(), true)) {
            return true;
        }

        $locationIds = $this->scopedLocationIds();
        if (empty($locationIds)) {
            return false;
        }

        // branch's own location in scope?
        if (in_array($branch->location_id, $locationIds, true)) {
            return true;
        }

        // any ancestor location in scope? (match by full_path prefix)
        $branchPath = $branch->location?->full_path;
        if (! $branchPath) {
            return false;
        }

        return Location::whereIn('id', $locationIds)
            ->get(['full_path'])
            ->contains(fn ($loc) => str_starts_with($branchPath, $loc->full_path.'/') || $branchPath === $loc->full_path);
    }

    /**
     * True if the user may publish/unpublish a given page instance:
     *  - super_admin: Gate::before bypass.
     *  - pages.publish (global): any page.
     *  - pages.publish.scoped (editor): only when the page's location is within
     *    one of the user's scoped locations (self or descendant, via full_path).
     */
    public function canPublishPage(PageInstance $page): bool
    {
        $locationIds = $this->scopedLocationIds();
        if (empty($locationIds)) {
            return false;
        }

        $pagePath = $page->location?->full_path;
        if (! $pagePath) {
            return false;
        }

        return Location::whereIn('id', $locationIds)
            ->get(['full_path'])
            ->contains(fn ($loc) => $pagePath === $loc->full_path || str_starts_with($pagePath, $loc->full_path.'/'));
    }

    /**
     * Query of page instances this user may publish within, used by scoped
     * bulk actions. Global publishers get everything; scoped editors get only
     * pages whose location full_path falls under their scoped locations.
     */
    public function scopedPageInstances(): Builder
    {
        $query = PageInstance::query();

        if ($this->hasRole('super_admin') || $this->can('pages.publish')) {
            return $query;
        }

        $scopedPaths = Location::whereIn('id', $this->scopedLocationIds())
            ->pluck('full_path')
            ->filter()
            ->all();

        if (empty($scopedPaths)) {
            return $query->whereRaw('1 = 0'); // no scope -> nothing
        }

        return $query->whereHas('location', function ($q) use ($scopedPaths) {
            $q->where(function ($inner) use ($scopedPaths) {
                foreach ($scopedPaths as $path) {
                    $inner->orWhere('full_path', $path)
                        ->orWhere('full_path', 'like', $path.'/%');
                }
            });
        });
    }
}
