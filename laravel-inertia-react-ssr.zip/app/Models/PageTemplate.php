<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class PageTemplate extends Model
{
    protected $fillable = [
        'key', 'name', 'slug_pattern', 'path_prefix',
        'requires_product', 'applies_to', 'requires_branch',
        'default_published', 'default_priority', 'default_changefreq',
        'view_component', 'title_pattern', 'description_pattern', 'is_active',
    ];

    protected $casts = [
        'applies_to' => 'array',
        'requires_product' => 'boolean',
        'requires_branch' => 'boolean',
        'default_published' => 'boolean',
        'default_priority' => 'decimal:1',
        'is_active' => 'boolean',
    ];

    public function pageInstances(): HasMany
    {
        return $this->hasMany(PageInstance::class);
    }

    public function scopeActive(Builder $q): Builder
    {
        return $q->where('is_active', true);
    }

    /* ---------------- token rendering ---------------- */

    /**
     * Replace {product}, {location}, {location_path} tokens in any pattern.
     */
    public function renderPattern(?string $pattern, ?Product $product, Location $location): ?string
    {
        if ($pattern === null) {
            return null;
        }

        return strtr($pattern, [
            '{product}' => $product?->slug ?? '',
            '{product_name}' => $product?->name ?? '',
            '{location}' => $location->slug,
            '{location_name}' => $location->name,
            '{location_path}' => $location->full_path ?? $location->slug,
        ]);
    }

    /**
     * Build the full, normalised url_path for a given product+location.
     * e.g. "/best-mobile-phones-nearme-in-chennai"
     */
    public function buildUrlPath(?Product $product, Location $location): string
    {
        $slug = $this->renderPattern($this->slug_pattern, $product, $location);
        $path = trim($this->path_prefix, '/').'/'.trim($slug, '/');
        $path = '/'.trim($path, '/');

        // collapse accidental double slashes
        return preg_replace('#/+#', '/', $path);
    }
}
