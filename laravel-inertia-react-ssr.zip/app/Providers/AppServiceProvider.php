<?php

namespace App\Providers;

use App\Models\Booking;
use App\Models\Branch;
use App\Models\PageInstance;
use App\Models\User;
use App\Policies\BookingPolicy;
use App\Policies\BranchPolicy;
use App\Policies\PagePolicy;
use App\Policies\UserPolicy;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    public function register(): void
    {
        //
    }

    public function boot(): void
    {
        // super_admin bypasses every ability. Returning null lets other
        // roles fall through to their normal permission/policy checks.
        Gate::before(function ($user, string $ability) {
            return $user->hasRole('super_admin') ? true : null;
        });

        Gate::policy(Branch::class, BranchPolicy::class);
        Gate::policy(Booking::class, BookingPolicy::class);
        Gate::policy(PageInstance::class, PagePolicy::class);
        Gate::policy(User::class, UserPolicy::class);
    }
}
