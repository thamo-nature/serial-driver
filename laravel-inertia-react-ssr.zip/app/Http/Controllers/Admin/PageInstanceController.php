<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Jobs\PurgePageCache;
use App\Models\PageInstance;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

/**
 * Admin management of programmatic SEO pages (select/deselect publishing).
 * All queries are scoped to what the user may publish:
 *   - global publishers (admin/super) see everything,
 *   - scoped editors see only pages under their assigned locations.
 */
class PageInstanceController extends Controller
{
    public function index(Request $request): JsonResponse
    {
        $this->authorize('viewAny', PageInstance::class);

        $pages = $request->user()->scopedPageInstances()
            ->with(['location:id,name,full_path', 'product:id,name', 'template:id,key'])
            ->when($request->filled('group'), fn ($q) => $q->where('sitemap_group', $request->string('group')))
            ->when($request->filled('published'), fn ($q) => $q->where('is_published', $request->boolean('published')))
            ->orderBy('url_path')
            ->paginate(50);

        return response()->json($pages);
    }

    public function bulkPublish(Request $request): JsonResponse
    {
        return $this->bulkSetPublished($request, true);
    }

    public function bulkUnpublish(Request $request): JsonResponse
    {
        return $this->bulkSetPublished($request, false);
    }

    /**
     * Bulk publish/unpublish. Every targeted page is authorized individually
     * against PagePolicy@publish, so a scoped editor cannot flip pages outside
     * their locations even if IDs are supplied.
     */
    private function bulkSetPublished(Request $request, bool $publish): JsonResponse
    {
        $validated = $request->validate([
            'ids' => ['required', 'array', 'min:1'],
            'ids.*' => ['integer'],
        ]);

        $user = $request->user();

        // Restrict candidate rows to the user's publish scope up front.
        $pages = $user->scopedPageInstances()
            ->with('location:id,full_path')
            ->whereIn('id', $validated['ids'])
            ->get();

        $authorizedIds = [];
        $denied = [];

        foreach ($pages as $page) {
            if ($user->can('publish', $page)) {
                $authorizedIds[] = $page->id;
            } else {
                $denied[] = $page->id;
            }
        }

        // IDs that were requested but not even in scope (filtered out above).
        $outOfScope = array_values(array_diff($validated['ids'], $pages->pluck('id')->all()));

        $updated = 0;
        if (! empty($authorizedIds)) {
            $authorizedPages = $pages->whereIn('id', $authorizedIds);

            $updated = DB::table('page_instances')
                ->whereIn('id', $authorizedIds)
                ->update([
                    'is_published' => $publish,
                    'published_at' => $publish ? now() : null,
                    'updated_at' => now(),
                ]);

            // Bulk update bypasses Eloquent events, so dispatch ONE purge job
            // with all affected URLs (cache + sitemap + CDN). Debounced by the
            // queue if using uniqueId.
            $base = rtrim(config('app.url'), '/');
            $urls = $authorizedPages->map(fn ($p) => $base.$p->url_path)->values()->all();
            PurgePageCache::dispatch($urls);
        }

        return response()->json([
            'updated' => $updated,
            'published' => $publish,
            'denied' => $denied,
            'out_of_scope' => $outOfScope,
        ]);
    }
}
