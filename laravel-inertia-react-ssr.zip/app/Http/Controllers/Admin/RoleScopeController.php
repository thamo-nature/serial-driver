<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\RoleScope;
use App\Models\User;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;
use Spatie\Permission\Models\Role;

/**
 * Role + scope administration (roles.manage).
 *  - list available roles,
 *  - sync a user's roles (UserPolicy@manageRoles guards super_admin),
 *  - attach/detach branch/location scopes that constrain managers/editors.
 */
class RoleScopeController extends Controller
{
    /** List assignable roles. */
    public function roles(Request $request): JsonResponse
    {
        abort_unless($request->user()->can('roles.manage'), 403);

        return response()->json(Role::query()->orderBy('name')->get(['id', 'name']));
    }

    /** Replace a user's roles. */
    public function syncRoles(Request $request, User $user): JsonResponse
    {
        $this->authorize('manageRoles', $user);

        $data = $request->validate([
            'roles' => ['required', 'array'],
            'roles.*' => ['string', Rule::exists('roles', 'name')],
        ]);

        // Only a super_admin may grant the super_admin role.
        if (in_array('super_admin', $data['roles'], true) && ! $request->user()->hasRole('super_admin')) {
            abort(403, 'Only a super_admin may grant super_admin.');
        }

        $user->syncRoles($data['roles']);

        return response()->json($user->fresh('roles:id,name'));
    }

    /** List a user's scopes. */
    public function scopes(Request $request, User $user): JsonResponse
    {
        $this->authorize('manageRoles', $user);

        return response()->json(
            $user->roleScopes()->with(['branch:id,name', 'location:id,name,full_path'])->get()
        );
    }

    /** Attach a branch or location scope to a user. */
    public function attachScope(Request $request, User $user): JsonResponse
    {
        $this->authorize('manageRoles', $user);

        $data = $request->validate([
            'scope_type' => ['required', Rule::in(['branch', 'location'])],
            'branch_id' => ['required_if:scope_type,branch', 'nullable', 'exists:branches,id'],
            'location_id' => ['required_if:scope_type,location', 'nullable', 'exists:locations,id'],
        ]);

        $scope = RoleScope::updateOrCreate(
            [
                'user_id' => $user->id,
                'scope_type' => $data['scope_type'],
                'branch_id' => $data['branch_id'] ?? null,
                'location_id' => $data['location_id'] ?? null,
            ],
            []
        );

        return response()->json($scope, 201);
    }

    /** Detach a scope from a user. */
    public function detachScope(Request $request, User $user, RoleScope $scope): JsonResponse
    {
        $this->authorize('manageRoles', $user);

        abort_unless($scope->user_id === $user->id, 404);

        $scope->delete();

        return response()->json(['detached' => true]);
    }
}
