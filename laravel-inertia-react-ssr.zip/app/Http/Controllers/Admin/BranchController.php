<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Branch;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

/**
 * Admin store (branch) management. Global managers see all branches; scoped
 * store managers see/edit only their own (via scopedBranchIds).
 */
class BranchController extends Controller
{
    public function index(Request $request): JsonResponse
    {
        $this->authorize('viewAny', Branch::class);

        $user = $request->user();

        $query = Branch::query()->with('location:id,name,full_path');

        // Scoped managers: restrict to their branches. Global managers: all.
        if (! $user->can('branches.manage')) {
            $query->whereIn('id', $user->scopedBranchIds());
        }

        return response()->json($query->orderBy('name')->paginate(50));
    }

    public function show(Request $request, Branch $branch): JsonResponse
    {
        $this->authorize('view', $branch);

        return response()->json($branch->load('location:id,name,full_path'));
    }

    public function store(Request $request): JsonResponse
    {
        $this->authorize('create', Branch::class);

        $data = $this->validateBranch($request);
        $branch = Branch::create($data);

        return response()->json($branch, 201);
    }

    public function update(Request $request, Branch $branch): JsonResponse
    {
        $this->authorize('update', $branch);

        $branch->update($this->validateBranch($request, false));

        return response()->json($branch);
    }

    public function destroy(Request $request, Branch $branch): JsonResponse
    {
        $this->authorize('delete', $branch);

        $branch->delete();

        return response()->json(['deleted' => true]);
    }

    private function validateBranch(Request $request, bool $requireLocation = true): array
    {
        return $request->validate([
            'location_id' => [$requireLocation ? 'required' : 'sometimes', 'exists:locations,id'],
            'name' => ['required', 'string', 'max:255'],
            'address_line1' => ['nullable', 'string', 'max:255'],
            'address_line2' => ['nullable', 'string', 'max:255'],
            'city' => ['nullable', 'string', 'max:255'],
            'state' => ['nullable', 'string', 'max:255'],
            'postal_code' => ['nullable', 'string', 'max:20'],
            'country' => ['nullable', 'string', 'max:2'],
            'phone' => ['nullable', 'string', 'max:40'],
            'email' => ['nullable', 'email', 'max:255'],
            'lat' => ['nullable', 'numeric'],
            'lng' => ['nullable', 'numeric'],
            'gbp_place_id' => ['nullable', 'string', 'max:255'],
            'gbp_cid' => ['nullable', 'string', 'max:255'],
            'gbp_location_id' => ['nullable', 'string', 'max:255'],
            'is_active' => ['boolean'],
        ]);
    }
}
