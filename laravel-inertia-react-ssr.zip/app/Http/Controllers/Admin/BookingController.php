<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Resources\BookingResource;
use App\Models\Booking;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\AnonymousResourceCollection;

/**
 * Admin/manager booking management. Global managers see all bookings; scoped
 * store managers see only bookings for their branches.
 */
class BookingController extends Controller
{
    public function index(Request $request): AnonymousResourceCollection
    {
        $this->authorize('viewAny', Booking::class);

        $user = $request->user();

        $query = Booking::query()->with('branch:id,name,city');

        if (! $user->can('bookings.manage')) {
            // scoped manager -> only their branches
            $query->whereIn('branch_id', $user->scopedBranchIds());
        }

        $query->when($request->filled('status'), fn ($q) => $q->where('status', $request->string('status')))
            ->when($request->filled('branch_id'), fn ($q) => $q->where('branch_id', $request->integer('branch_id')))
            ->latest('scheduled_at');

        return BookingResource::collection($query->paginate(50));
    }

    public function show(Request $request, Booking $booking): BookingResource
    {
        $this->authorize('view', $booking);

        return new BookingResource($booking->load('branch:id,name,city'));
    }

    public function update(Request $request, Booking $booking): BookingResource
    {
        $this->authorize('update', $booking);

        $data = $request->validate([
            'status' => ['required', 'in:pending,confirmed,completed,cancelled'],
            'scheduled_at' => ['sometimes', 'date'],
            'notes' => ['nullable', 'string'],
        ]);

        $booking->update($data);

        return new BookingResource($booking->fresh('branch'));
    }

    public function destroy(Request $request, Booking $booking): JsonResponse
    {
        $this->authorize('delete', $booking);

        $booking->delete();

        return response()->json(['deleted' => true]);
    }
}
