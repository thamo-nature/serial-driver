<?php

namespace App\Http\Controllers;

use App\Models\PageInstance;
use App\Services\Seo\SeoBuilder;
use Illuminate\Http\Request;
use Inertia\Inertia;

/**
 * Catch-all resolver for programmatic SEO pages. Resolves the incoming path
 * against page_instances.url_path (SSOT) in a single indexed lookup, enforces
 * is_published, then renders the template's React component with the SEO
 * payload so SSR emits all meta/JSON-LD into the initial HTML.
 */
class PageController extends Controller
{
    public function show(Request $request, SeoBuilder $seoBuilder)
    {
        // Normalise to a leading-slash path, no trailing slash (except root).
        $path = '/'.trim($request->path(), '/');

        $instance = PageInstance::query()
            ->with(['template', 'product', 'location.branches'])
            ->where('url_path', $path)
            ->first();

        abort_if($instance === null, 404);
        abort_unless($instance->is_published, 404);

        $seo = $seoBuilder->forInstance($instance);

        $inertia = Inertia::render($instance->template->view_component, [
            'instance' => [
                'url_path' => $instance->url_path,
                'product' => $instance->product?->only(['id', 'name', 'slug']),
                'location' => $instance->location->only(['id', 'name', 'slug', 'full_path']),
            ],
            'seo' => $seo,
            'branches' => $instance->location->branches
                ->where('is_active', true)
                ->map->only(['id', 'name', 'address_line1', 'city', 'state', 'phone', 'lat', 'lng'])
                ->values(),
        ]);

        // Convert to an HTTP response so we can mark it full-page cacheable.
        // Only full (non-Inertia-XHR) GET responses are cached; the CachePage
        // middleware reads this header on a MISS. Inertia's partial/XHR visits
        // carry the X-Inertia header and must NOT be full-page cached.
        $response = $inertia->toResponse($request);

        if (! $request->header('X-Inertia')) {
            $response->headers->set('X-Page-Cacheable', '1');
        }

        return $response;
    }
}
