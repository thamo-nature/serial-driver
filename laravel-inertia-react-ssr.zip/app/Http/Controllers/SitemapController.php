<?php

namespace App\Http\Controllers;

use App\Models\PageInstance;
use App\Services\Seo\CachePurger;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Cache;
use Inertia\Inertia;

/**
 * Sitemaps, driven entirely by the SSOT (page_instances, forSitemap scope =
 * is_published AND indexable). All URLs built from config('app.url').
 *
 *   /sitemap.xml                 -> <sitemapindex> of per-group child sitemaps
 *   /sitemap-{group}.xml         -> <urlset> for one sitemap_group
 *   /sitemap-{group}-{page}.xml  -> chunk N of a large group (> max_urls)
 *   /sitemap                     -> HTML sitemap (Inertia page)
 *
 * SCALE:
 *   - XML cached keyed by the sitemap VERSION (bumped on publish) — Part O.
 *   - gzip: responds .xml.gz / gzip-encoded when the client accepts it
 *     (Google accepts gzipped sitemaps; keeps files under the 50MB cap).
 *   - chunking: a group with > max_urls_per_file URLs is split into numbered
 *     children listed in the index, so a group can scale past 50,000 URLs.
 */
class SitemapController extends Controller
{
    public function __construct(private CachePurger $purger) {}

    private function maxUrls(): int
    {
        return (int) config('seo.sitemap.max_urls_per_file', 45000);
    }

    /* ----------------------------------------------------------------- index */

    public function index(Request $request): Response
    {
        $xml = Cache::remember(
            $this->purger->sitemapKey('index'),
            (int) config('seo.cache.ttl', 86400),
            fn () => $this->buildIndexXml(),
        );

        return $this->xml($request, $xml);
    }

    private function buildIndexXml(): string
    {
        $max = $this->maxUrls();
        $base = rtrim(config('app.url'), '/');

        // per-group counts + lastmod drive how many child files each group needs
        $groups = PageInstance::query()
            ->forSitemap()
            ->selectRaw('sitemap_group, COUNT(*) as cnt, MAX(updated_at) as lastmod')
            ->groupBy('sitemap_group')
            ->get();

        $xml = '<?xml version="1.0" encoding="UTF-8"?>'."\n";
        $xml .= '<sitemapindex xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">'."\n";

        foreach ($groups as $group) {
            $slug = $group->sitemap_group ?: 'root';
            $pages = (int) ceil($group->cnt / $max);
            $lastmod = $group->lastmod ? Carbon::parse($group->lastmod)->toAtomString() : null;

            if ($pages <= 1) {
                $xml .= $this->indexEntry("{$base}/sitemap-".urlencode($slug).'.xml', $lastmod);
            } else {
                for ($i = 1; $i <= $pages; $i++) {
                    $xml .= $this->indexEntry("{$base}/sitemap-".urlencode($slug)."-{$i}.xml", $lastmod);
                }
            }
        }

        $xml .= '</sitemapindex>';

        return $xml;
    }

    private function indexEntry(string $loc, ?string $lastmod): string
    {
        $entry = "  <sitemap>\n    <loc>".e($loc)."</loc>\n";
        if ($lastmod) {
            $entry .= '    <lastmod>'.$lastmod."</lastmod>\n";
        }

        return $entry."  </sitemap>\n";
    }

    /* ----------------------------------------------------------------- group */

    /** A group sitemap, optionally a specific chunk page (1-based). */
    public function group(Request $request, string $group, ?int $page = null): Response
    {
        $page = $page ?: 1;

        $xml = Cache::remember(
            $this->purger->sitemapKey("group:{$group}:{$page}"),
            (int) config('seo.cache.ttl', 86400),
            fn () => $this->buildGroupXml($group, $page),
        );

        return $this->xml($request, $xml);
    }

    private function buildGroupXml(string $group, int $page): string
    {
        $max = $this->maxUrls();
        $base = rtrim(config('app.url'), '/');

        $pages = PageInstance::query()
            ->forSitemap()
            ->where('sitemap_group', $group)
            ->orderBy('url_path')
            ->offset(($page - 1) * $max)
            ->limit($max)
            ->get(['url_path', 'priority', 'changefreq', 'updated_at']);

        $xml = '<?xml version="1.0" encoding="UTF-8"?>'."\n";
        $xml .= '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">'."\n";
        foreach ($pages as $p) {
            $xml .= "  <url>\n";
            $xml .= '    <loc>'.e($base.$p->url_path)."</loc>\n";
            $xml .= '    <lastmod>'.$p->updated_at->toAtomString()."</lastmod>\n";
            $xml .= '    <changefreq>'.e($p->changefreq)."</changefreq>\n";
            $xml .= '    <priority>'.number_format((float) $p->priority, 1)."</priority>\n";
            $xml .= "  </url>\n";
        }
        $xml .= '</urlset>';

        return $xml;
    }

    /* ------------------------------------------------------------------ util */

    /**
     * Return XML, gzip-encoded when the request accepts gzip OR the path ends
     * in .gz. Google fetches gzipped sitemaps fine and it keeps files small.
     */
    private function xml(Request $request, string $xml): Response
    {
        $wantsGzip = str_ends_with($request->path(), '.gz')
            || str_contains((string) $request->header('Accept-Encoding'), 'gzip');

        if ($wantsGzip && function_exists('gzencode')) {
            return response(gzencode($xml, 9), 200)->withHeaders([
                'Content-Type' => 'application/xml',
                'Content-Encoding' => 'gzip',
                'Vary' => 'Accept-Encoding',
            ]);
        }

        return response($xml, 200)->withHeaders([
            'Content-Type' => 'application/xml',
            'Vary' => 'Accept-Encoding',
        ]);
    }

    /* ------------------------------------------------------------------ html */

    public function html()
    {
        $base = rtrim(config('app.url'), '/');

        $groups = PageInstance::query()
            ->forSitemap()
            ->with('location:id,name')
            ->orderBy('sitemap_group')
            ->orderBy('url_path')
            ->get(['id', 'location_id', 'url_path', 'sitemap_group', 'meta_title'])
            ->groupBy('sitemap_group')
            ->map(fn ($items) => $items->map(fn ($p) => [
                'title' => $p->meta_title ?: $p->url_path,
                'url' => $base.$p->url_path,
            ])->values());

        return Inertia::render('Sitemap/Index', [
            'groups' => $groups,
        ]);
    }
}
