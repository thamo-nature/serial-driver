<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Resources\BookingResource;
use App\Models\Booking;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\AnonymousResourceCollection;

/**
 * Mobile/customer booking API (Sanctum auth:sanctum).
 * A 'user' (customer) creates, lists, and cancels ONLY their own bookings.
 * Authorization via BookingPolicy (owner checks).
 */
class BookingController extends Controller
{
    public function index(Request $request): AnonymousResourceCollection
    {
        $bookings = Booking::query()
            ->where('user_id', $request->user()->id)
            ->with('branch:id,name,city')
            ->latest('scheduled_at')
            ->paginate(20);

        return BookingResource::collection($bookings);
    }

    public function store(Request $request): JsonResponse
    {
        $this->authorize('create', Booking::class);

        $data = $request->validate([
            'branch_id' => ['required', 'exists:branches,id'],
            'customer_name' => ['required', 'string', 'max:255'],
            'customer_phone' => ['nullable', 'string', 'max:40'],
            'customer_email' => ['nullable', 'email', 'max:255'],
            'scheduled_at' => ['required', 'date', 'after:now'],
            'notes' => ['nullable', 'string'],
        ]);

        $booking = Booking::create([
            ...$data,
            'user_id' => $request->user()->id,
            'status' => 'pending',
        ]);

        return (new BookingResource($booking->load('branch:id,name,city')))
            ->response()
            ->setStatusCode(201);
    }

    public function show(Request $request, Booking $booking): BookingResource
    {
        $this->authorize('view', $booking); // owner-only for customers

        return new BookingResource($booking->load('branch:id,name,city'));
    }

    public function cancel(Request $request, Booking $booking): BookingResource
    {
        $this->authorize('cancel', $booking);

        $booking->update(['status' => 'cancelled']);

        return new BookingResource($booking->fresh('branch'));
    }
}
