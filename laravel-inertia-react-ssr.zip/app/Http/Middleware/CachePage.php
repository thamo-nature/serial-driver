<?php

namespace App\Http\Middleware;

use App\Services\Seo\CachePurger;
use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Cache;
use Symfony\Component\HttpFoundation\Response;

/**
 * Full-page HTML cache for public, published SEO pages.
 *
 * On a HIT, the cached HTML is returned immediately — the request NEVER reaches
 * PageController or the Node SSR process, which is what lets a crawler storm hit
 * thousands of programmatic pages cheaply (Part I.1 Layer 1).
 *
 * Caching only applies when ALL of these hold:
 *   - seo.cache.enabled is true,
 *   - GET request,
 *   - guest (no authenticated session — never cache personalised HTML),
 *   - no query string (canonical, cache-friendly URLs only),
 *   - the downstream response is 200 and marks itself cacheable
 *     (PageController sets X-Page-Cacheable: 1 for published pages).
 *
 * Keys are version-stamped by CachePurger, so publishing/unpublishing a page
 * (which bumps the version) instantly invalidates every cached page.
 */
class CachePage
{
    public function __construct(private CachePurger $purger) {}

    public function handle(Request $request, Closure $next): Response
    {
        if (! $this->cacheable($request)) {
            return $next($request);
        }

        $key = $this->purger->pageKey('/'.trim($request->path(), '/'));

        // HIT: serve stored HTML, bypassing the controller + SSR entirely.
        if ($cached = Cache::get($key)) {
            return response($cached['content'], 200)
                ->withHeaders($cached['headers'])
                ->header('X-Page-Cache', 'HIT');
        }

        // MISS: run the request, store if the controller marked it cacheable.
        $response = $next($request);

        if ($this->storable($response)) {
            Cache::put($key, [
                'content' => $response->getContent(),
                'headers' => [
                    'Content-Type' => $response->headers->get('Content-Type', 'text/html; charset=UTF-8'),
                ],
            ], (int) config('seo.cache.ttl', 86400));

            $response->headers->set('X-Page-Cache', 'MISS');
        }

        return $response;
    }

    private function cacheable(Request $request): bool
    {
        return config('seo.cache.enabled', false)
            && $request->isMethod('GET')
            && ! $request->user()               // guests only
            && empty($request->getQueryString()) // canonical URLs only
            && ! $request->is('admin*', 'api*', 'sitemap*', 'robots.txt', 'up');
    }

    private function storable(Response $response): bool
    {
        return $response->getStatusCode() === 200
            && $response->headers->get('X-Page-Cacheable') === '1';
    }
}
