<?php

namespace App\Http\Middleware;

use App\Models\Redirect as RedirectRule;
use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

/**
 * Looks up the incoming path in the redirects table and issues a 301/302
 * BEFORE the page resolver runs, so slug changes preserve SEO equity and
 * never surface a 404. to_path may be a relative path or an absolute URL.
 */
class HandleRedirects
{
    public function handle(Request $request, Closure $next): Response
    {
        $from = '/'.trim($request->path(), '/');

        $rule = RedirectRule::query()
            ->where('is_active', true)
            ->where('from_path', $from)
            ->first();

        if ($rule) {
            $target = str_starts_with($rule->to_path, 'http')
                ? $rule->to_path
                : rtrim(config('app.url'), '/').'/'.ltrim($rule->to_path, '/');

            return redirect()->away($target, $rule->status_code);
        }

        return $next($request);
    }
}
