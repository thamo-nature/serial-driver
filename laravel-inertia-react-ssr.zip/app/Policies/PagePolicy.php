<?php

namespace App\Policies;

use App\Models\PageInstance;
use App\Models\User;

/**
 * Page instance (programmatic SEO page) authorization.
 *  - super_admin : Gate::before bypass.
 *  - admin       : pages.publish (global) -> publish/unpublish any page.
 *  - editor      : pages.publish.scoped -> only within their scoped locations.
 *  - pages.edit  : edit meta/SEO (separate from publish).
 */
class PagePolicy
{
    public function viewAny(User $user): bool
    {
        return $user->hasAnyPermission(['pages.view', 'pages.edit', 'pages.publish', 'pages.publish.scoped']);
    }

    public function view(User $user, PageInstance $page): bool
    {
        return $user->can('pages.view') || $this->update($user, $page) || $this->publish($user, $page);
    }

    public function update(User $user, PageInstance $page): bool
    {
        // editing meta/SEO
        if ($user->can('pages.edit')) {
            // scoped editors may only edit within their locations
            if ($user->can('pages.publish') || ! $user->hasRole('editor')) {
                return true;
            }

            return $user->canPublishPage($page);
        }

        return false;
    }

    public function publish(User $user, PageInstance $page): bool
    {
        if ($user->can('pages.publish')) {
            return true;
        }

        return $user->can('pages.publish.scoped') && $user->canPublishPage($page);
    }
}
