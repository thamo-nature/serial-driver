<?php

namespace App\Policies;

use App\Models\User;

/**
 * User administration (users.manage). super_admin is bypassed by Gate::before.
 * Guards:
 *  - only super_admin may act on another super_admin,
 *  - nobody may delete themselves via the admin endpoint.
 */
class UserPolicy
{
    public function viewAny(User $actor): bool
    {
        return $actor->can('users.manage');
    }

    public function view(User $actor, User $target): bool
    {
        return $actor->can('users.manage');
    }

    public function create(User $actor): bool
    {
        return $actor->can('users.manage');
    }

    public function update(User $actor, User $target): bool
    {
        if (! $actor->can('users.manage')) {
            return false;
        }

        // Only a super_admin can modify another super_admin.
        if ($target->hasRole('super_admin')) {
            return $actor->hasRole('super_admin');
        }

        return true;
    }

    public function delete(User $actor, User $target): bool
    {
        if ($actor->id === $target->id) {
            return false; // no self-delete
        }

        if ($target->hasRole('super_admin')) {
            return false; // never delete a super_admin via this endpoint
        }

        return $actor->can('users.manage');
    }

    /** Assigning roles/scopes is a separate, higher privilege. */
    public function manageRoles(User $actor, User $target): bool
    {
        if (! $actor->can('roles.manage')) {
            return false;
        }

        // Only super_admin can grant/alter super_admin.
        if ($target->hasRole('super_admin')) {
            return $actor->hasRole('super_admin');
        }

        return true;
    }
}
