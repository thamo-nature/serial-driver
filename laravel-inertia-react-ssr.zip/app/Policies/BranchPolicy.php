<?php

namespace App\Policies;

use App\Models\Branch;
use App\Models\User;

/**
 * Branch (store) access.
 *  - super_admin: bypassed in Gate::before.
 *  - admin: global 'branches.manage' permission -> any branch.
 *  - manager: no global manage; may update ONLY branches in their scope.
 * viewAny is allowed for anyone who can manage branches at all (the query is
 * then filtered to their scope in the controller).
 */
class BranchPolicy
{
    public function viewAny(User $user): bool
    {
        return $user->hasAnyPermission(['branches.view', 'branches.manage'])
            || $user->hasRole('manager');
    }

    public function view(User $user, Branch $branch): bool
    {
        if ($user->can('branches.manage')) {
            return true;
        }

        return $user->canManageBranch($branch);
    }

    public function create(User $user): bool
    {
        // Only global managers may create branches (not scoped store managers).
        return $user->can('branches.manage');
    }

    public function update(User $user, Branch $branch): bool
    {
        if ($user->can('branches.manage')) {
            return true;
        }

        // scoped manager editing their own store
        return $user->can('branches.manage.scoped') && $user->canManageBranch($branch);
    }

    public function delete(User $user, Branch $branch): bool
    {
        // Deletion is a global/admin action only.
        return $user->can('branches.manage');
    }
}
