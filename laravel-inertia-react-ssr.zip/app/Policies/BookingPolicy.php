<?php

namespace App\Policies;

use App\Models\Booking;
use App\Models\User;

/**
 * Booking access.
 *  - super_admin: bypassed in Gate::before.
 *  - admin: global 'bookings.manage' -> all bookings.
 *  - manager: manage bookings for branches in their scope.
 *  - user (customer): view/cancel only their OWN bookings.
 */
class BookingPolicy
{
    public function viewAny(User $user): bool
    {
        return $user->hasAnyPermission(['bookings.manage', 'bookings.view.own'])
            || $user->hasRole('manager');
    }

    public function view(User $user, Booking $booking): bool
    {
        if ($user->can('bookings.manage')) {
            return true;
        }

        // owner (customer)
        if ($booking->user_id === $user->id) {
            return true;
        }

        // scoped manager for the booking's branch
        return $user->can('bookings.manage.scoped')
            && in_array($booking->branch_id, $user->scopedBranchIds(), true);
    }

    public function create(User $user): bool
    {
        // customers create their own bookings; managers/admins may also create.
        return $user->hasAnyPermission(['bookings.create', 'bookings.manage'])
            || $user->hasRole('manager');
    }

    public function update(User $user, Booking $booking): bool
    {
        if ($user->can('bookings.manage')) {
            return true;
        }

        return $user->can('bookings.manage.scoped')
            && in_array($booking->branch_id, $user->scopedBranchIds(), true);
    }

    public function cancel(User $user, Booking $booking): bool
    {
        // owner may cancel their own; managers/admins per update rule.
        if ($booking->user_id === $user->id) {
            return true;
        }

        return $this->update($user, $booking);
    }

    public function delete(User $user, Booking $booking): bool
    {
        return $user->can('bookings.manage');
    }
}
