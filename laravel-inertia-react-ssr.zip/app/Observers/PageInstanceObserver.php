<?php

namespace App\Observers;

use App\Jobs\PurgePageCache;
use App\Models\PageInstance;
use App\Models\Redirect;

/**
 * Keeps SEO integrity automatic:
 *  - url_path change  -> create a 301 Redirect (old -> new) so no equity/404.
 *  - publish/url/meta change -> dispatch a queued PurgePageCache (cache +
 *    sitemap + CDN) for the affected URL.
 *  - delete -> purge.
 *
 * Absolute URLs are built from config('app.url') so UAT/Live stays consistent.
 */
class PageInstanceObserver
{
    public function updated(PageInstance $page): void
    {
        // 1. url_path changed -> record a redirect from the OLD path.
        if ($page->wasChanged('url_path')) {
            $old = $page->getOriginal('url_path');
            $new = $page->url_path;

            if ($old && $old !== $new) {
                Redirect::updateOrCreate(
                    ['from_path' => $old],
                    ['to_path' => $new, 'status_code' => 301, 'is_active' => true],
                );
            }
        }

        // 2. anything that affects what is served/indexed -> purge.
        if ($page->wasChanged(['url_path', 'is_published', 'indexable', 'meta_title', 'meta_description', 'canonical_override'])) {
            $this->dispatchPurge($page);
        }
    }

    public function deleted(PageInstance $page): void
    {
        $this->dispatchPurge($page);
    }

    private function dispatchPurge(PageInstance $page): void
    {
        $base = rtrim(config('app.url'), '/');
        $urls = [$base.$page->url_path];

        // include the OLD url too if it just changed
        $old = $page->getOriginal('url_path');
        if ($old && $old !== $page->url_path) {
            $urls[] = $base.$old;
        }

        PurgePageCache::dispatch($urls);
    }
}
