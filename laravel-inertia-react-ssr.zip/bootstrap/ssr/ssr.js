import { createInertiaApp } from "@inertiajs/react";
import createServer from "@inertiajs/react/server";
import ReactDOMServer from "react-dom/server";
import { jsx } from "react/jsx-runtime";
// node_modules/laravel-vite-plugin/inertia-helpers/index.js
async function resolvePageComponent(path, pages) {
	for (const p of Array.isArray(path) ? path : [path]) {
		const page = pages[p];
		if (typeof page === "undefined") continue;
		return typeof page === "function" ? page() : page;
	}
	throw new Error(`Page not found: ${path}`);
}
// resources/js/ssr.jsx
var appName = "Laravel";
createServer((page) => createInertiaApp({
	page,
	render: ReactDOMServer.renderToString,
	title: (title) => `${title} - ${appName}`,
	resolve: (name) => resolvePageComponent(`./pages/${name}.jsx`, /* #__PURE__ */ Object.assign({
		"./pages/Locations/ProductNearMe.jsx": () => import("./assets/ProductNearMe-C6SB53AE.js"),
		"./pages/Sitemap/Index.jsx": () => import("./assets/Index-Cgsy8M8N.js"),
		"./pages/Welcome.jsx": () => import("./assets/Welcome-SMoPVIlV.js")
	})),
	setup: ({ App, props }) => /* @__PURE__ */ jsx(App, { ...props })
}));
export {};
