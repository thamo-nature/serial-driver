import { Head } from "@inertiajs/react";
import { Fragment, jsx, jsxs } from "react/jsx-runtime";
// resources/js/pages/Locations/ProductNearMe.jsx
/**
* Programmatic location page. Renders all SEO tags + JSON-LD into <Head> so
* SSR emits them in the initial HTML (View Source) for crawlers.
*
* Props (from PageController@show):
*   seo      : { title, description, canonical, robots, og, breadcrumb[], schema }
*   instance : { url_path, product, location }
*   branches : [{ name, address_line1, city, state, phone, lat, lng }]
*/
function ProductNearMe({ seo, instance, branches = [] }) {
	return /* @__PURE__ */ jsxs(Fragment, { children: [
		/* @__PURE__ */ jsxs(Head, { children: [
			/* @__PURE__ */ jsx("title", { children: seo.title }),
			/* @__PURE__ */ jsx("meta", {
				name: "description",
				content: seo.description
			}),
			/* @__PURE__ */ jsx("meta", {
				name: "robots",
				content: seo.robots
			}),
			/* @__PURE__ */ jsx("link", {
				rel: "canonical",
				href: seo.canonical
			}),
			/* @__PURE__ */ jsx("meta", {
				property: "og:title",
				content: seo.og.title
			}),
			/* @__PURE__ */ jsx("meta", {
				property: "og:description",
				content: seo.og.description
			}),
			/* @__PURE__ */ jsx("meta", {
				property: "og:url",
				content: seo.og.url
			}),
			/* @__PURE__ */ jsx("meta", {
				property: "og:type",
				content: seo.og.type
			}),
			/* @__PURE__ */ jsx("script", {
				type: "application/ld+json",
				children: JSON.stringify(seo.schema)
			})
		] }),
		/* @__PURE__ */ jsx("nav", {
			"aria-label": "breadcrumb",
			children: /* @__PURE__ */ jsx("ol", {
				style: {
					display: "flex",
					gap: 8,
					listStyle: "none",
					padding: 0
				},
				children: seo.breadcrumb.map((item, i) => /* @__PURE__ */ jsxs("li", { children: [/* @__PURE__ */ jsx("a", {
					href: item.url,
					children: item.name
				}), i < seo.breadcrumb.length - 1 ? " ›" : ""] }, i))
			})
		}),
		/* @__PURE__ */ jsxs("main", {
			style: {
				maxWidth: 800,
				margin: "2rem auto",
				fontFamily: "sans-serif"
			},
			children: [
				/* @__PURE__ */ jsx("h1", { children: seo.title }),
				/* @__PURE__ */ jsx("p", { children: seo.description }),
				/* @__PURE__ */ jsx("p", { children: /* @__PURE__ */ jsx("a", {
					href: seo.lead_form_url,
					children: "Enquire now"
				}) }),
				branches.length > 0 && /* @__PURE__ */ jsxs("section", { children: [/* @__PURE__ */ jsxs("h2", { children: ["Nearby branches in ", instance.location.name] }), /* @__PURE__ */ jsx("ul", { children: branches.map((b) => /* @__PURE__ */ jsxs("li", { children: [
					/* @__PURE__ */ jsx("strong", { children: b.name }),
					" — ",
					b.address_line1,
					", ",
					b.city,
					b.phone ? ` (${b.phone})` : ""
				] }, b.id)) })] })
			]
		})
	] });
}
export { ProductNearMe as default };
