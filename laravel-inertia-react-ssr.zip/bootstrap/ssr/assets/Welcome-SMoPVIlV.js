import { Head } from "@inertiajs/react";
import { jsx, jsxs } from "react/jsx-runtime";
// resources/js/pages/Welcome.jsx
function Welcome({ laravelVersion, phpVersion }) {
	return /* @__PURE__ */ jsxs("div", {
		className: "flex flex-col items-center justify-center min-h-screen bg-gray-100 text-gray-800",
		children: [
			/* @__PURE__ */ jsx(Head, { title: "Welcome" }),
			/* @__PURE__ */ jsx("h1", {
				className: "text-4xl font-bold mb-4",
				children: "Laravel + Inertia + React SSR"
			}),
			/* @__PURE__ */ jsxs("p", {
				className: "text-lg",
				children: [
					"Running on Laravel v",
					laravelVersion,
					" (PHP v",
					phpVersion,
					")"
				]
			})
		]
	});
}
export { Welcome as default };
