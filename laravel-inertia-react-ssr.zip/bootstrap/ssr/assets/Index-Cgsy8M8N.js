import { Head } from "@inertiajs/react";
import { Fragment, jsx, jsxs } from "react/jsx-runtime";
// resources/js/pages/Sitemap/Index.jsx
/**
* HTML sitemap. Same SSOT data as /sitemap.xml, grouped for humans.
* Props: groups = { [sitemap_group]: [{ title, url }] }
*/
function SitemapIndex({ groups = {} }) {
	const groupKeys = Object.keys(groups);
	return /* @__PURE__ */ jsxs(Fragment, { children: [/* @__PURE__ */ jsxs(Head, { children: [/* @__PURE__ */ jsx("title", { children: "Sitemap" }), /* @__PURE__ */ jsx("meta", {
		name: "robots",
		content: "index,follow"
	})] }), /* @__PURE__ */ jsxs("main", {
		style: {
			maxWidth: 900,
			margin: "2rem auto",
			fontFamily: "sans-serif"
		},
		children: [
			/* @__PURE__ */ jsx("h1", { children: "Sitemap" }),
			groupKeys.length === 0 && /* @__PURE__ */ jsx("p", { children: "No published pages yet." }),
			groupKeys.map((group) => /* @__PURE__ */ jsxs("section", { children: [/* @__PURE__ */ jsx("h2", {
				style: { textTransform: "capitalize" },
				children: group
			}), /* @__PURE__ */ jsx("ul", { children: groups[group].map((page, i) => /* @__PURE__ */ jsx("li", { children: /* @__PURE__ */ jsx("a", {
				href: page.url,
				children: page.title
			}) }, i)) })] }, group))
		]
	})] });
}
export { SitemapIndex as default };
