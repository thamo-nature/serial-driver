// PM2 process manager config for production.
// Runs the Inertia SSR bundle in CLUSTER mode (one worker per CPU core) so a
// crawler storm / traffic spike is spread across all cores instead of a single
// Node process (Part I.1 Layer 2). Also runs the Laravel queue worker that
// processes PurgePageCache + sitemap regeneration jobs.
//
// Usage:
//   npm run build && npx vite build --ssr      # produce bootstrap/ssr/ssr.js
//   pm2 start ecosystem.config.cjs
//   pm2 reload ecosystem.config.cjs            # zero-downtime reload after deploy
//   pm2 logs / pm2 status / pm2 monit
//   pm2 save && pm2 startup                    # persist across reboots
//
// NOTE: the SSR bundle path is bootstrap/ssr/ssr.js for this build (not .mjs);
// verify with `ls bootstrap/ssr` after building (see Part J.1).

module.exports = {
  apps: [
    {
      name: 'inertia-ssr',
      // The compiled Inertia SSR server bundle.
      script: 'bootstrap/ssr/ssr.js',
      // Cluster across all CPU cores; PM2 load-balances connections.
      instances: 'max',
      exec_mode: 'cluster',
      // SSR is stateless -> safe to restart/scale freely.
      autorestart: true,
      max_memory_restart: '512M',
      watch: false,
      env: {
        NODE_ENV: 'production',
      },
    },
    {
      name: 'laravel-queue',
      // Processes cache/sitemap/CDN purge jobs (PurgePageCache) etc.
      script: 'artisan',
      interpreter: 'php',
      args: 'queue:work --queue=default --sleep=1 --tries=3 --max-time=3600',
      instances: 1,
      exec_mode: 'fork',
      autorestart: true,
      max_memory_restart: '256M',
      watch: false,
    },
  ],
};
