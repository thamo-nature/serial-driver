<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Global indexability (UAT vs Live switch)
    |--------------------------------------------------------------------------
    | false on UAT/staging  -> every page renders noindex,nofollow + robots.txt
    |                          Disallow: /
    | true on Live          -> pages render index/noindex per is_published +
    |                          per-page indexable flag.
    | Flip via the SEO_INDEXABLE env var only — never hardcode in pages.
    */
    'indexable' => (bool) env('SEO_INDEXABLE', false),

    /*
    |--------------------------------------------------------------------------
    | Lead form URL (switches UAT -> Live via env)
    |--------------------------------------------------------------------------
    */
    'lead_form_url' => env('LEAD_FORM_URL', env('APP_URL').'/lead'),

    /*
    |--------------------------------------------------------------------------
    | Sitemap
    |--------------------------------------------------------------------------
    | max_urls_per_file stays safely under Google's 50,000 hard limit so the
    | sitemap index can chunk deterministically.
    */
    'sitemap' => [
        'max_urls_per_file' => (int) env('SITEMAP_MAX_URLS', 45000),
    ],

    /*
    |--------------------------------------------------------------------------
    | Page cache (read-through) + sitemap cache
    |--------------------------------------------------------------------------
    | enabled    : turn page/sitemap caching on (off by default in local/UAT).
    | ttl        : seconds to cache a rendered page / sitemap.
    | tag        : cache tag used when the store supports tagging (Redis).
    |              On non-taggable stores (database/file) the CachePurger falls
    |              back to a version key so purges still invalidate content.
    */
    'cache' => [
        'enabled' => (bool) env('SEO_CACHE_ENABLED', false),
        'ttl' => (int) env('SEO_CACHE_TTL', 86400), // 24h
        'tag' => env('SEO_CACHE_TAG', 'seo-pages'),
    ],

    /*
    |--------------------------------------------------------------------------
    | CDN purge hook
    |--------------------------------------------------------------------------
    | driver : 'log' (default; records intended purges) | 'cloudflare'.
    | Cloudflare uses zone_id + api_token and purges by Cache-Tag or URL.
    | Keep secrets in .env, never hardcode.
    */
    'cdn' => [
        'driver' => env('CDN_DRIVER', 'log'),
        'cloudflare' => [
            'zone_id' => env('CLOUDFLARE_ZONE_ID'),
            'api_token' => env('CLOUDFLARE_API_TOKEN'),
        ],
    ],

];
