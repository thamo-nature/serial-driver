import { Head } from '@inertiajs/react';

/**
 * HTML sitemap. Same SSOT data as /sitemap.xml, grouped for humans.
 * Props: groups = { [sitemap_group]: [{ title, url }] }
 */
export default function SitemapIndex({ groups = {} }) {
    const groupKeys = Object.keys(groups);

    return (
        <>
            <Head>
                <title>Sitemap</title>
                <meta name="robots" content="index,follow" />
            </Head>

            <main style={{ maxWidth: 900, margin: '2rem auto', fontFamily: 'sans-serif' }}>
                <h1>Sitemap</h1>
                {groupKeys.length === 0 && <p>No published pages yet.</p>}
                {groupKeys.map((group) => (
                    <section key={group}>
                        <h2 style={{ textTransform: 'capitalize' }}>{group}</h2>
                        <ul>
                            {groups[group].map((page, i) => (
                                <li key={i}>
                                    <a href={page.url}>{page.title}</a>
                                </li>
                            ))}
                        </ul>
                    </section>
                ))}
            </main>
        </>
    );
}
