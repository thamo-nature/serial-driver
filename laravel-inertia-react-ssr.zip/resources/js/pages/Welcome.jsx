import { Head } from '@inertiajs/react';

export default function Welcome({ laravelVersion, phpVersion }) {
    return (
        <div className="flex flex-col items-center justify-center min-h-screen bg-gray-100 text-gray-800">
            <Head title="Welcome" />
            <h1 className="text-4xl font-bold mb-4">Laravel + Inertia + React SSR</h1>
            <p className="text-lg">Running on Laravel v{laravelVersion} (PHP v{phpVersion})</p>
        </div>
    );
}
