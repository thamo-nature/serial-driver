import { Head } from '@inertiajs/react';

/**
 * Programmatic location page. Renders all SEO tags + JSON-LD into <Head> so
 * SSR emits them in the initial HTML (View Source) for crawlers.
 *
 * Props (from PageController@show):
 *   seo      : { title, description, canonical, robots, og, breadcrumb[], schema }
 *   instance : { url_path, product, location }
 *   branches : [{ name, address_line1, city, state, phone, lat, lng }]
 */
export default function ProductNearMe({ seo, instance, branches = [] }) {
    return (
        <>
            <Head>
                <title>{seo.title}</title>
                <meta name="description" content={seo.description} />
                <meta name="robots" content={seo.robots} />
                <link rel="canonical" href={seo.canonical} />
                <meta property="og:title" content={seo.og.title} />
                <meta property="og:description" content={seo.og.description} />
                <meta property="og:url" content={seo.og.url} />
                <meta property="og:type" content={seo.og.type} />
                {/* JSON-LD must be a single stringified child */}
                <script type="application/ld+json">
                    {JSON.stringify(seo.schema)}
                </script>
            </Head>

            {/* Breadcrumb trail */}
            <nav aria-label="breadcrumb">
                <ol style={{ display: 'flex', gap: 8, listStyle: 'none', padding: 0 }}>
                    {seo.breadcrumb.map((item, i) => (
                        <li key={i}>
                            <a href={item.url}>{item.name}</a>
                            {i < seo.breadcrumb.length - 1 ? ' ›' : ''}
                        </li>
                    ))}
                </ol>
            </nav>

            <main style={{ maxWidth: 800, margin: '2rem auto', fontFamily: 'sans-serif' }}>
                <h1>{seo.title}</h1>
                <p>{seo.description}</p>

                <p>
                    <a href={seo.lead_form_url}>Enquire now</a>
                </p>

                {branches.length > 0 && (
                    <section>
                        <h2>Nearby branches in {instance.location.name}</h2>
                        <ul>
                            {branches.map((b) => (
                                <li key={b.id}>
                                    <strong>{b.name}</strong> — {b.address_line1}, {b.city}
                                    {b.phone ? ` (${b.phone})` : ''}
                                </li>
                            ))}
                        </ul>
                    </section>
                )}
            </main>
        </>
    );
}
