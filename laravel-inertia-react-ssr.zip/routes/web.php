<?php

use App\Http\Controllers\Admin\BookingController;
use App\Http\Controllers\Admin\BranchController;
use App\Http\Controllers\Admin\PageInstanceController;
use App\Http\Controllers\Admin\RoleScopeController;
use App\Http\Controllers\Admin\UserController;
use App\Http\Controllers\PageController;
use App\Http\Controllers\SitemapController;
use App\Http\Middleware\CachePage;
use App\Http\Middleware\HandleRedirects;
use Illuminate\Support\Facades\Route;
use Inertia\Inertia;

/*
|--------------------------------------------------------------------------
| Home
|--------------------------------------------------------------------------
*/
Route::get('/', function () {
    return Inertia::render('Welcome', [
        'laravelVersion' => app()->version(),
        'phpVersion' => PHP_VERSION,
    ]);
})->name('home');

/*
|--------------------------------------------------------------------------
| Sitemaps (SSOT-driven) + dynamic robots.txt
| Declared BEFORE the catch-all so they are not swallowed by it.
|--------------------------------------------------------------------------
*/
Route::get('/sitemap.xml', [SitemapController::class, 'index'])->name('sitemap.index');
Route::get('/sitemap.xml.gz', [SitemapController::class, 'index'])->name('sitemap.index.gz');
// Chunked child: /sitemap-{group}-{page}.xml  (page = 1-based chunk)
Route::get('/sitemap-{group}-{page}.xml', [SitemapController::class, 'group'])
    ->where('group', '[a-z0-9-]+?')->where('page', '[0-9]+')->name('sitemap.group.page');
Route::get('/sitemap-{group}.xml', [SitemapController::class, 'group'])
    ->where('group', '[a-z0-9-]+')->name('sitemap.group');
Route::get('/sitemap-{group}.xml.gz', [SitemapController::class, 'group'])->name('sitemap.group.gz');
Route::get('/sitemap', [SitemapController::class, 'html'])->name('sitemap.html');

Route::get('/robots.txt', function () {
    $base = rtrim(config('app.url'), '/');

    if (! config('seo.indexable', false)) {
        // UAT / non-indexable: block all crawling.
        $content = "User-agent: *\nDisallow: /\n";
    } else {
        $content = "User-agent: *\n"
            ."Allow: /\n"
            ."Disallow: /admin\n"
            ."Disallow: /api\n"
            ."Sitemap: {$base}/sitemap.xml\n";
    }

    return response($content, 200)->header('Content-Type', 'text/plain');
})->name('robots');

/*
|--------------------------------------------------------------------------
| Admin area (web, session auth). Role/permission gated; policies enforce
| per-branch / per-location scope inside the controllers.
| Declared BEFORE the catch-all.
|--------------------------------------------------------------------------
*/
Route::middleware(['auth'])
    ->prefix('admin')
    ->name('admin.')
    ->group(function () {
        // Pages: editors (scoped) + admins (global). Publishing authorized per row.
        Route::middleware('permission:pages.view|pages.edit|pages.publish|pages.publish.scoped')
            ->group(function () {
                Route::get('pages', [PageInstanceController::class, 'index'])->name('pages.index');
                Route::post('pages/bulk-publish', [PageInstanceController::class, 'bulkPublish'])->name('pages.bulk-publish');
                Route::post('pages/bulk-unpublish', [PageInstanceController::class, 'bulkUnpublish'])->name('pages.bulk-unpublish');
            });

        // Branches: global managers (admin) + scoped store managers.
        Route::middleware('permission:branches.view|branches.manage|branches.manage.scoped')
            ->group(function () {
                Route::get('branches', [BranchController::class, 'index'])->name('branches.index');
                Route::get('branches/{branch}', [BranchController::class, 'show'])->name('branches.show');
                Route::post('branches', [BranchController::class, 'store'])->name('branches.store');
                Route::put('branches/{branch}', [BranchController::class, 'update'])->name('branches.update');
                Route::delete('branches/{branch}', [BranchController::class, 'destroy'])->name('branches.destroy');
            });

        // Bookings: global managers (admin) + scoped store managers.
        Route::middleware('permission:bookings.manage|bookings.manage.scoped')
            ->group(function () {
                Route::get('bookings', [BookingController::class, 'index'])->name('bookings.index');
                Route::get('bookings/{booking}', [BookingController::class, 'show'])->name('bookings.show');
                Route::put('bookings/{booking}', [BookingController::class, 'update'])->name('bookings.update');
                Route::delete('bookings/{booking}', [BookingController::class, 'destroy'])->name('bookings.destroy');
            });

        // Users: admin user management (users.manage).
        Route::middleware('permission:users.manage')
            ->group(function () {
                Route::get('users', [UserController::class, 'index'])->name('users.index');
                Route::get('users/{user}', [UserController::class, 'show'])->name('users.show');
                Route::post('users', [UserController::class, 'store'])->name('users.store');
                Route::put('users/{user}', [UserController::class, 'update'])->name('users.update');
                Route::delete('users/{user}', [UserController::class, 'destroy'])->name('users.destroy');
            });

        // Roles & scopes: higher privilege (roles.manage).
        Route::middleware('permission:roles.manage')
            ->group(function () {
                Route::get('roles', [RoleScopeController::class, 'roles'])->name('roles.index');
                Route::put('users/{user}/roles', [RoleScopeController::class, 'syncRoles'])->name('users.roles.sync');
                Route::get('users/{user}/scopes', [RoleScopeController::class, 'scopes'])->name('users.scopes.index');
                Route::post('users/{user}/scopes', [RoleScopeController::class, 'attachScope'])->name('users.scopes.attach');
                Route::delete('users/{user}/scopes/{scope}', [RoleScopeController::class, 'detachScope'])->name('users.scopes.detach');
            });
    });

/*
|--------------------------------------------------------------------------
| Programmatic SEO catch-all — MUST be the LAST web route.
| Redirects middleware runs first (301/302 on slug changes), then the
| PageController resolves page_instances.url_path.
|--------------------------------------------------------------------------
*/
Route::get('/{any}', [PageController::class, 'show'])
    ->where('any', '.*')
    ->middleware([HandleRedirects::class, CachePage::class])
    ->name('page.show');
