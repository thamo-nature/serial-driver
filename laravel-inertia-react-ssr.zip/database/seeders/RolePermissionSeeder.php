<?php

namespace Database\Seeders;

use App\Models\Branch;
use App\Models\Location;
use App\Models\RoleScope;
use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;
use Spatie\Permission\Models\Permission;
use Spatie\Permission\Models\Role;
use Spatie\Permission\PermissionRegistrar;

/**
 * Seeds the 5-role model and sample users.
 *
 * Roles:
 *   super_admin - everything (also bypassed via Gate::before)
 *   admin       - global management minus super-admin/user-role control
 *   manager     - scoped: manage their stores (branches) + their bookings
 *   editor      - scoped: SEO publish/unpublish for assigned locations
 *   user        - customer: own bookings only
 *
 * Scope (role_scopes) is what limits manager/editor to specific stores/areas.
 */
class RolePermissionSeeder extends Seeder
{
    public function run(): void
    {
        app(PermissionRegistrar::class)->forgetCachedPermissions();

        $permissions = [
            // users & roles
            'users.manage', 'roles.manage',
            // locations & products & templates
            'locations.manage', 'products.manage', 'templates.manage',
            // SEO / page publishing
            'pages.view', 'pages.edit', 'pages.publish', 'pages.publish.scoped',
            // branches (stores)
            'branches.view', 'branches.manage', 'branches.manage.scoped',
            // bookings
            'bookings.view.own', 'bookings.create',
            'bookings.manage', 'bookings.manage.scoped',
        ];

        foreach ($permissions as $p) {
            Permission::findOrCreate($p, 'web');
        }

        // super_admin: no explicit perms needed (Gate::before bypass), but give
        // all for completeness / non-gate checks.
        $superAdmin = Role::findOrCreate('super_admin', 'web');
        $superAdmin->syncPermissions(Permission::all());

        $admin = Role::findOrCreate('admin', 'web');
        $admin->syncPermissions([
            'locations.manage', 'products.manage', 'templates.manage',
            'pages.view', 'pages.edit', 'pages.publish',
            'branches.view', 'branches.manage',
            'bookings.view.own', 'bookings.create', 'bookings.manage',
            'users.manage',
            // NOTE: no 'roles.manage' -> cannot mint super_admins.
        ]);

        $manager = Role::findOrCreate('manager', 'web');
        $manager->syncPermissions([
            'branches.view', 'branches.manage.scoped',
            'bookings.create', 'bookings.manage.scoped',
            'pages.view',
        ]);

        $editor = Role::findOrCreate('editor', 'web');
        $editor->syncPermissions([
            'pages.view', 'pages.edit', 'pages.publish.scoped',
        ]);

        $user = Role::findOrCreate('user', 'web');
        $user->syncPermissions([
            'bookings.view.own', 'bookings.create',
        ]);

        $this->seedSampleUsers();
    }

    private function seedSampleUsers(): void
    {
        $superAdmin = User::updateOrCreate(
            ['email' => 'superadmin@example.com'],
            ['name' => 'Super Admin', 'password' => Hash::make('password')]
        );
        $superAdmin->syncRoles(['super_admin']);

        $admin = User::updateOrCreate(
            ['email' => 'admin@example.com'],
            ['name' => 'Admin', 'password' => Hash::make('password')]
        );
        $admin->syncRoles(['admin']);

        // Chennai store manager: scoped to the Chennai branch.
        $manager = User::updateOrCreate(
            ['email' => 'chennai.manager@example.com'],
            ['name' => 'Chennai Manager', 'password' => Hash::make('password')]
        );
        $manager->syncRoles(['manager']);

        $chennaiBranch = Branch::whereHas('location', fn ($q) => $q->where('slug', 'chennai'))->first();
        if ($chennaiBranch) {
            RoleScope::updateOrCreate(
                ['user_id' => $manager->id, 'scope_type' => 'branch', 'branch_id' => $chennaiBranch->id, 'location_id' => null],
                []
            );
        }

        // Tamil Nadu editor: scoped to the tamil-nadu location subtree.
        $editor = User::updateOrCreate(
            ['email' => 'tn.editor@example.com'],
            ['name' => 'Tamil Nadu Editor', 'password' => Hash::make('password')]
        );
        $editor->syncRoles(['editor']);

        $tnLocation = Location::where('slug', 'tamil-nadu')->first();
        if ($tnLocation) {
            RoleScope::updateOrCreate(
                ['user_id' => $editor->id, 'scope_type' => 'location', 'branch_id' => null, 'location_id' => $tnLocation->id],
                []
            );
        }

        // Customer
        $customer = User::updateOrCreate(
            ['email' => 'customer@example.com'],
            ['name' => 'Customer', 'password' => Hash::make('password')]
        );
        $customer->syncRoles(['user']);
    }
}
