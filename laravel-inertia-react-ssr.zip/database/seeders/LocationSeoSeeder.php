<?php

namespace Database\Seeders;

use App\Models\Branch;
use App\Models\Location;
use App\Models\LocationType;
use App\Models\PageTemplate;
use App\Models\Product;
use Illuminate\Database\Seeder;
use Illuminate\Support\Str;

/**
 * Seeds:
 *   - location_types: country>state>city>district>village (expandable)
 *   - a location tree rooted at India (sample states/cities/districts/villages)
 *   - a sample product "Best Mobile Phones"
 *   - a page template "best-mobile-phones-nearme" (product x location)
 *   - a couple of sample branches (GBP) on city nodes
 *
 * Run pages:generate afterwards to fan out page_instances.
 */
class LocationSeoSeeder extends Seeder
{
    /** @var array<string,LocationType> */
    private array $types = [];

    public function run(): void
    {
        $this->seedTypes();
        $this->seedTree();
        $this->seedProduct();
        $this->seedTemplate();
    }

    private function seedTypes(): void
    {
        $defs = [
            ['key' => 'country',  'label' => 'Country',  'level' => 1],
            ['key' => 'state',    'label' => 'State',    'level' => 2],
            ['key' => 'city',     'label' => 'City',     'level' => 3],
            ['key' => 'district', 'label' => 'District', 'level' => 4],
            ['key' => 'village',  'label' => 'Village',  'level' => 5],
        ];

        foreach ($defs as $d) {
            $this->types[$d['key']] = LocationType::updateOrCreate(
                ['key' => $d['key']],
                ['label' => $d['label'], 'level' => $d['level'], 'is_active' => true]
            );
        }
    }

    /**
     * Sample, expandable tree. Add more villages/subdistricts later by simply
     * inserting rows (or extending this array) — no schema change needed.
     */
    private function seedTree(): void
    {
        $tree = [
            'India' => [
                'Tamil Nadu' => [
                    'Chennai' => ['Tambaram' => ['Selaiyur', 'Rajakilpakkam'], 'Ambattur' => ['Mogappair']],
                    'Coimbatore' => ['Peelamedu' => ['Hopes'], 'Gandhipuram' => []],
                ],
                'Karnataka' => [
                    'Bengaluru' => ['Whitefield' => ['Kadugodi'], 'Jayanagar' => []],
                    'Mysuru' => ['Vijayanagar' => []],
                ],
            ],
        ];

        foreach ($tree as $countryName => $states) {
            $country = $this->makeLocation($countryName, 'country', null);
            foreach ($states as $stateName => $cities) {
                $state = $this->makeLocation($stateName, 'state', $country);
                foreach ($cities as $cityName => $districts) {
                    $city = $this->makeLocation($cityName, 'city', $state);
                    // sample GBP branch per city
                    $this->makeBranch($city);
                    foreach ($districts as $districtName => $villages) {
                        $district = $this->makeLocation($districtName, 'district', $city);
                        foreach ($villages as $villageName) {
                            $this->makeLocation($villageName, 'village', $district);
                        }
                    }
                }
            }
        }
    }

    private function makeLocation(string $name, string $typeKey, ?Location $parent): Location
    {
        $type = $this->types[$typeKey];
        $slug = Str::slug($name);

        $location = Location::updateOrCreate(
            ['parent_id' => $parent?->id, 'slug' => $slug],
            [
                'location_type_id' => $type->id,
                'depth' => $type->level,
                'name' => $name,
                'is_active' => true,
            ]
        );

        // full_path = parent full_path + slug
        $location->full_path = $parent && $parent->full_path
            ? $parent->full_path.'/'.$slug
            : $slug;
        $location->save();

        return $location;
    }

    private function makeBranch(Location $city): void
    {
        Branch::updateOrCreate(
            ['location_id' => $city->id, 'name' => "Store - {$city->name}"],
            [
                'address_line1' => "1 Main Road, {$city->name}",
                'city' => $city->name,
                'state' => $city->parent?->name,
                'country' => 'IN',
                'phone' => '+91-44-00000000',
                'gbp_place_id' => 'PLACEID_'.strtoupper($city->slug),
                'is_active' => true,
            ]
        );
    }

    private function seedProduct(): void
    {
        Product::updateOrCreate(
            ['slug' => 'best-mobile-phones'],
            [
                'name' => 'Best Mobile Phones',
                'description' => 'Find the best mobile phones near you.',
                'is_active' => true,
            ]
        );
    }

    private function seedTemplate(): void
    {
        PageTemplate::updateOrCreate(
            ['key' => 'best-mobile-phones-nearme'],
            [
                'name' => 'Best Mobile Phones Near Me (by location)',
                // -> /best-mobile-phones-nearme-in-chennai
                'slug_pattern' => '{product}-nearme-in-{location}',
                'path_prefix' => '',
                'requires_product' => true,
                'applies_to' => ['country', 'state', 'city', 'district', 'village'],
                'requires_branch' => false,
                'default_published' => false,
                'default_priority' => 0.7,
                'default_changefreq' => 'weekly',
                'view_component' => 'Locations/ProductNearMe',
                'title_pattern' => '{product_name} Near Me in {location_name}',
                'description_pattern' => 'Discover the {product_name} near you in {location_name}. Compare prices and offers.',
                'is_active' => true,
            ]
        );
    }
}
