<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * role_scopes constrains a user's authority to specific parts of the location
 * tree / specific stores. Global RBAC (spatie roles) answers "what KIND of
 * action", role_scopes answers "on WHICH branches/locations".
 *
 * A manager is scoped to one or more BRANCHES (individual stores).
 * An editor may be scoped to one or more LOCATIONS (a city/state subtree).
 * super_admin and admin need NO scopes (global) — enforced in policies.
 *
 * scope_type = 'branch' | 'location'. Exactly one of the two FKs is set.
 */
return new class extends Migration
{
    public function up(): void
    {
        Schema::create('role_scopes', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained()->cascadeOnDelete();

            $table->string('scope_type'); // 'branch' | 'location'
            $table->foreignId('branch_id')->nullable()
                  ->constrained('branches')->cascadeOnDelete();
            $table->foreignId('location_id')->nullable()
                  ->constrained('locations')->cascadeOnDelete();

            $table->timestamps();

            $table->unique(['user_id', 'scope_type', 'branch_id', 'location_id'], 'role_scopes_unique');
            $table->index(['user_id', 'scope_type']);
            $table->index('branch_id');
            $table->index('location_id');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('role_scopes');
    }
};
