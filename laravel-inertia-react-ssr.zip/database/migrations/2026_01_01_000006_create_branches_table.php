<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * branches = physical presence per location, mapped to a Google Business
 * Profile. Source of truth for both the GBP API sync AND the on-page
 * LocalBusiness JSON-LD. Keep NAP identical to the live GBP.
 *
 * A location (e.g. a city) can have 0..N branches.
 */
return new class extends Migration
{
    public function up(): void
    {
        Schema::create('branches', function (Blueprint $table) {
            $table->id();
            $table->foreignId('location_id')
                  ->constrained('locations')->cascadeOnDelete();

            // NAP (Name, Address, Phone) — must match the GBP exactly
            $table->string('name');
            $table->string('address_line1')->nullable();
            $table->string('address_line2')->nullable();
            $table->string('city')->nullable();
            $table->string('state')->nullable();
            $table->string('postal_code')->nullable();
            $table->string('country')->default('IN');
            $table->string('phone')->nullable();
            $table->string('email')->nullable();

            // geo for LocalBusiness schema + maps
            $table->decimal('lat', 10, 7)->nullable();
            $table->decimal('lng', 10, 7)->nullable();

            // Google Business Profile identifiers (programmatic management)
            $table->string('gbp_place_id')->nullable()->index(); // Google Place ID
            $table->string('gbp_cid')->nullable();               // Maps CID
            $table->string('gbp_location_id')->nullable();       // GBP API resource id

            $table->boolean('is_active')->default(true);
            $table->timestamps();

            $table->index('location_id');
            $table->index('is_active');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('branches');
    }
};
