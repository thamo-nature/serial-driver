<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * bookings: a customer (user) books an appointment at a branch (store).
 * Governs the real data that manager (their branches) and user (their own)
 * permissions act on.
 */
return new class extends Migration
{
    public function up(): void
    {
        Schema::create('bookings', function (Blueprint $table) {
            $table->id();
            $table->foreignId('branch_id')->constrained('branches')->cascadeOnDelete();
            $table->foreignId('user_id')->nullable()
                  ->constrained('users')->nullOnDelete(); // customer who booked

            $table->string('customer_name');
            $table->string('customer_phone')->nullable();
            $table->string('customer_email')->nullable();

            $table->dateTime('scheduled_at');
            // pending -> confirmed -> completed | cancelled
            $table->string('status')->default('pending');
            $table->text('notes')->nullable();

            $table->timestamps();

            $table->index('branch_id');
            $table->index('user_id');
            $table->index('status');
            $table->index('scheduled_at');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('bookings');
    }
};
