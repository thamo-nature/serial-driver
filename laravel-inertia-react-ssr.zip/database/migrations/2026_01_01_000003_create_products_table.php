<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * products are DATA, not code. 5 today, N tomorrow. Adding a product is an
 * INSERT; running pages:generate fans it out into page_instances.
 *
 * Example: name "Best Mobile Phones", slug "best-mobile-phones".
 */
return new class extends Migration
{
    public function up(): void
    {
        Schema::create('products', function (Blueprint $table) {
            $table->id();
            $table->string('name');                 // "Best Mobile Phones"
            $table->string('slug')->unique();       // "best-mobile-phones"
            $table->text('description')->nullable();
            $table->boolean('is_active')->default(true);
            $table->unsignedInteger('sort_order')->default(0);

            // default SEO building blocks (templated per page)
            $table->string('meta_title')->nullable();
            $table->string('meta_description', 500)->nullable();

            $table->timestamps();

            $table->index('is_active');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('products');
    }
};
