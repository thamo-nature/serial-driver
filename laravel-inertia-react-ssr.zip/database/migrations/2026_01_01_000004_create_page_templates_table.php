<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * page_templates define page TYPES as data. A template says:
 *   - how to build the URL (slug_pattern with {product} / {location} tokens)
 *   - whether it needs a product (requires_product)
 *   - which location TYPES it may target (applies_to)  <-- keeps matrix SPARSE
 *   - which React component renders it (view_component)
 *
 * Example row for your sample:
 *   key           = "best-mobile-phones-nearme"
 *   slug_pattern  = "{product}-nearme-in-{location}"
 *   requires_product = true
 *   applies_to    = ["country","state","city","district","village"]
 *   view_component= "Locations/ProductNearMe"
 * -> yields url_path like "/best-mobile-phones-nearme-in-chennai"
 */
return new class extends Migration
{
    public function up(): void
    {
        Schema::create('page_templates', function (Blueprint $table) {
            $table->id();
            $table->string('key')->unique();           // machine key
            $table->string('name');                    // human label

            // URL building. Tokens: {product}, {location}, {location_path}
            //   {location}      = the location's own slug (e.g. "chennai")
            //   {location_path} = full_path (e.g. "tamil-nadu/chennai")
            $table->string('slug_pattern');

            // "/" prefix for the generated url_path (e.g. "" or "/loans")
            $table->string('path_prefix')->default('');

            $table->boolean('requires_product')->default(false);

            // which location_type keys this template may generate for
            $table->json('applies_to');                // ["city","district",...]

            // eligibility: only generate where a branch exists, etc.
            $table->boolean('requires_branch')->default(false);

            // default publish state for newly generated instances (keep false)
            $table->boolean('default_published')->default(false);

            // default sitemap hints
            $table->decimal('default_priority', 2, 1)->default(0.5); // 0.0–1.0
            $table->string('default_changefreq')->default('weekly');

            // React page component (lowercase pages/ resolved client-side)
            $table->string('view_component');

            // SEO title/description templates (tokens allowed)
            $table->string('title_pattern')->nullable();
            $table->string('description_pattern', 500)->nullable();

            $table->boolean('is_active')->default(true);
            $table->timestamps();

            $table->index('is_active');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('page_templates');
    }
};
