<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * page_instances = SINGLE SOURCE OF TRUTH.
 * One row per (template x product? x location) combination.
 *
 * This one table drives, all from the SAME data so they can never drift:
 *   - ROUTING    : resolve incoming URL via unique(url_path)
 *   - PUBLISHING : is_published is the select/deselect switch
 *   - SITEMAP    : WHERE is_published = 1 (+ sitemap_group for chunking)
 *   - SEO/robots : indexable + is_published + env -> robots meta
 *
 * Sparse by design: only rows that pass template.applies_to (+ eligibility)
 * are generated. Adding a product/template/location = new rows, no code.
 */
return new class extends Migration
{
    public function up(): void
    {
        Schema::create('page_instances', function (Blueprint $table) {
            $table->id();

            // matrix dimensions
            $table->foreignId('page_template_id')
                  ->constrained('page_templates')->cascadeOnDelete();
            $table->foreignId('product_id')->nullable()
                  ->constrained('products')->cascadeOnDelete();
            $table->foreignId('location_id')
                  ->constrained('locations')->cascadeOnDelete();

            // materialised canonical path, e.g. "/best-mobile-phones-nearme-in-chennai"
            $table->string('url_path', 512);

            // SELECT / DESELECT switch
            $table->boolean('is_published')->default(false);

            // per-page robots override (AND-ed with env SEO_INDEXABLE)
            $table->boolean('indexable')->default(true);

            // sitemap fields
            $table->decimal('priority', 2, 1)->default(0.5);   // 0.0–1.0
            $table->string('changefreq')->default('weekly');
            // chunk key for sitemap index (e.g. state slug or template key)
            $table->string('sitemap_group')->nullable();

            // SEO overrides (fall back to template/product/location defaults)
            $table->string('meta_title')->nullable();
            $table->string('meta_description', 500)->nullable();
            // optional explicit canonical (else built from APP_URL + url_path)
            $table->string('canonical_override', 512)->nullable();

            $table->timestamp('published_at')->nullable();
            $table->timestamps();

            // one page per combination
            $table->unique(['page_template_id', 'product_id', 'location_id'], 'page_instances_matrix_unique');
            // routing lookup (url_path can be long -> cap index length)
            $table->unique('url_path');
            $table->index('is_published');
            $table->index('location_id');
            $table->index('product_id');
            $table->index('sitemap_group');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('page_instances');
    }
};
