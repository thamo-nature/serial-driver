<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * locations: one self-referencing table holds the WHOLE tree
 *   India (country) -> Tamil Nadu (state) -> Chennai (city)
 *        -> <district> -> <village/subdistrict>
 * Expandable to any depth (just add a deeper location_type + rows).
 *
 * full_path is a denormalised, indexed slug path ("india/tamil-nadu/chennai")
 * so a URL resolves in ONE indexed lookup instead of walking parents.
 */
return new class extends Migration
{
    public function up(): void
    {
        Schema::create('locations', function (Blueprint $table) {
            $table->id();

            // tree
            $table->foreignId('parent_id')->nullable()
                  ->constrained('locations')->nullOnDelete();
            $table->foreignId('location_type_id')
                  ->constrained('location_types')->cascadeOnDelete();
            $table->unsignedSmallInteger('depth')->default(0); // mirrors type level

            // identity
            $table->string('name');                 // "Chennai"
            $table->string('slug');                 // "chennai" (unique per parent)
            $table->string('full_path')->nullable();// "india/tamil-nadu/chennai"

            // geo (optional, used by LocalBusiness schema / maps)
            $table->decimal('lat', 10, 7)->nullable();
            $table->decimal('lng', 10, 7)->nullable();

            // ordering + lifecycle
            $table->unsignedInteger('sort_order')->default(0);
            $table->boolean('is_active')->default(true);

            // per-location SEO overrides (optional; fall back to template defaults)
            $table->string('meta_title')->nullable();
            $table->string('meta_description', 500)->nullable();

            $table->timestamps();

            // indexes for O(1)-ish routing + tree queries
            $table->unique(['parent_id', 'slug']);
            $table->unique('full_path');
            $table->index('location_type_id');
            $table->index('depth');
            $table->index('is_active');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('locations');
    }
};
