<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * location_types defines the levels of the geographic tree as DATA, so the
 * hierarchy is expandable without code changes. Seeded with:
 *   country(1) -> state(2) -> city(3) -> district(4) -> village(5)
 * Tomorrow you can add e.g. "zone" or "pincode" by inserting a row — no
 * migration needed.
 */
return new class extends Migration
{
    public function up(): void
    {
        Schema::create('location_types', function (Blueprint $table) {
            $table->id();
            $table->string('key')->unique();        // country|state|city|district|village
            $table->string('label');                // "Country", "State", ...
            $table->unsignedSmallInteger('level');  // 1,2,3,4,5 ... (tree depth)
            $table->boolean('is_active')->default(true);
            $table->timestamps();

            $table->index('level');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('location_types');
    }
};
