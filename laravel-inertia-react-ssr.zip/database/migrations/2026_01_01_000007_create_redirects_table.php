<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * redirects: when a location slug or url_path changes, the OLD url_path must
 * 301 -> the NEW one, or you lose SEO equity and create 404s. A middleware
 * looks up from_path here before falling through to the page resolver.
 *
 * Auto-created whenever a page_instance.url_path changes (see observer plan).
 */
return new class extends Migration
{
    public function up(): void
    {
        Schema::create('redirects', function (Blueprint $table) {
            $table->id();
            $table->string('from_path', 512)->unique(); // old "/...-in-chennai"
            $table->string('to_path', 512);             // new path OR absolute URL
            $table->unsignedSmallInteger('status_code')->default(301); // 301|302
            $table->boolean('is_active')->default(true);
            $table->timestamps();

            $table->index('is_active');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('redirects');
    }
};
